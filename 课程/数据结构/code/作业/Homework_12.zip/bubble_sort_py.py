
def bubble_sort(nums):
    for i in range(len(nums) - 1): 
        for j in range(len(nums) - i - 1): 
            if nums[j] > nums[j + 1]:
                nums[j], nums[j + 1] = nums[j + 1], nums[j]
    return nums
arr = input("Please enter an array of lines separated by spaces\n")
nums = [int(n) for n in arr.split()]
print("Bubble sorting succeeded")
print(bubble_sort(nums))