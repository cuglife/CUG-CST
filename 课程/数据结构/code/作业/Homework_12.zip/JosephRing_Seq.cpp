﻿#include<iostream>
using namespace std;

template<class T>
class SeqList
{
public:
	SeqList(int n = 0);
	~SeqList();
	void Creat(int n);							   //新建顺序表
	int Length() { return length; }			//获取表长
	void Insert(T& e, int);						//插入元素
	void Delete(T& e, int);						//删除元素
private:
	T* data;									//存放元素的数组
	int length;										//表的实际长度
	int size;											//表的最大长度
};

template<class T>
SeqList<T>::SeqList(int n) {
	length = 0;
	if (n == 0)
		data = NULL;				//人数为零，表空
	else
		data = new T[n];			//人数不为零，分配表一个长n的空间
	size = n;
}

template<class T>
SeqList<T>::~SeqList(){
	delete[]data;
}

template<class T>
void SeqList<T>::Creat(int n) {	//创建一个顺序表，并初始化
	for (int i = 0; i < n; i++) {
		data[i] = i + 1;
		cout << data[i] << " ";
	}
}
template<class T>
void SeqList<T>::Insert(T& e, int i) {
	if (i < 1 || i < length + 1) {
		cerr << "错误！" << endl; 
		exit(1);
	}

//如果实际长度比初始长度大，则扩大空间
	if (length >= size) {
		T* temp;
		temp = new T[size + 20];		
		for (int j = 0; j < length; j++)
			temp[j] = data[j];
		delete[]data;
		data = temp;
		size += 20;
	}

	T* travel, * former;
	former = &data[i - 1];																			//former指向报数的起始位置
	for (travel = &data[length - 1]; travel >= former; --travel)				//travel指向表尾
		* (travel + 1) = *travel;																	//将表尾元素插入到表尾的下个位置
	*former = e;																							//将现在的表尾赋为要插入的值
	++length;
}

template<class T>
void SeqList<T>::Delete(T& e, int i)
{
	if (i<1 || i>length + 1) {
		cerr << "错误！" << endl;
		exit(1);
	} 

	T* travel, * former;
	travel = &data[i - 1];							//travel指向表尾
	e = *travel;											//将表尾元素赋给要删除的元素
	former = data + length - 1;
	for (++travel; travel <= former; ++travel)				//将整个数组向前移一位
		* (travel - 1) = *travel;
	--length;																	//删除表尾元素
}

void  Joseph(int num, int i, int rank)
{
	SeqList<int> JosephList(num);
	for (i = 1; i <= num; i++)
		JosephList.Insert(i, i);							//将起始位置的序号插入到新表的相应位置
	for (int j = 1; j <= num; j++) {
		int length = JosephList.Length();		//获取新表长度
		int here = i + rank - 1;							//获取出列人的位置
		while (here > length)							//如果该位置超过了表长, 相减得到报完一圈后的位置
			here -= length;
		int people;
		JosephList.Delete(people, here);		//删除出列元素
		cout << people << " ";
		i = here;								//重新初始化起始位置
	}
}

int main()
{
	int num, start, rank;
	cout << "请输入总人数: ";
	cin >> num;
	SeqList<int> JosephList(num);
	cout << "请输入报数的起始位置:";
	cin >> start;
	cout << "请输入出列所报数字:";
	cin >> rank;
	cout << "原序列为：" << endl;
	JosephList.Creat(num);
	cout << endl;
	cout << "新序列为: " << endl;
	Joseph(num, start, rank);
	return 0;
}