﻿#include <iostream>
#include<vector>
using namespace std;
//C++ ver
void bubble_sort(vector<double> &vec)
{
	int i, j, length = vec.size();
	double temp;
	for (i = 0; i < length - 1; i++) {
		for (j = 0; j < length - 1 - i; j++) {
			if (vec[j] > vec[j + 1]) {
				temp = vec[j];
				vec[j] = vec[j + 1];
				vec[j + 1] = temp;
			}
		}	
	}
	for (int i = 0; i < length; i++) 
		cout << vec[i] << ' ';
}
int main()
{
	int x;
	vector<double> vec;
	cout << "Please enter a digital and end with a negative number" << endl << endl;
	while (cin>>x){
		vec.push_back(x);
		cout << "Sorting......" << endl;
		bubble_sort(vec);
		cout << endl << "Bubble sorting succeeded!" << endl << endl;
	}
	return 0;
}