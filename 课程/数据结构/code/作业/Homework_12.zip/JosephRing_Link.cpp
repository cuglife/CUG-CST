﻿#include<iostream>
using namespace std;
const int maxsize = 100;			//人数上限
struct LinkNode{
	int data;
	LinkNode* next;
};

//循环链表模板类
class CircularList{
public:
	CircularList();
	~CircularList();
	void create(int);
	void print();
	void Joseph(int i, int m);
private:
	int length;
	LinkNode* head;
};
CircularList::CircularList()	
{
	head = new LinkNode;
	head->data = 1;
	head->next = head;
}
CircularList::~CircularList()
{
	delete head;
	head = NULL;
}

void CircularList::create(int n)
{
	LinkNode* p = head;
	length = n;
	for (int i = 2; i <= n; i++)
	{
		LinkNode* q = new LinkNode;	//新建一个节点
		q->data = i;									//数据域赋为i;
		q->next = head;							//后继指向头结点以循环
		p->next = q;								//尾插q结点
		p = q;
	}
}
void CircularList::print()
{
	cout << head->data << " ";
	LinkNode* p = head->next;
	while (p != head){
		cout << p->data << " ";
		p = p->next;
	}
	cout << endl;
}
void CircularList::Joseph(int i, int m)
{
	LinkNode* p = head;		//工作指针
	int j = 1;
	while (j != i)	{
		j++;
		p = p->next;
	}
	for (int k = 1; k <= length; k++){
			LinkNode* q = p;		//指针指向开始数1的第i个人
			LinkNode* r = NULL;	//q的前驱指针
			j = 1;				//计数器,找到数m的人
			while (j != m){
				j++;
				r = q;
				q = q->next;
			}				//找到数m的人
			cout << q->data << " ";	//输出此人的序号
			r->next = q->next;  		//删除该结点
			p = r->next;
	}
	cout << endl;
}
int main()
{
	int num, start, rank;
	CircularList JosephList;

	cout << "请输入总人数: ";
	cin >> num;
	while (num > maxsize || num < 0){
		cout << "error! ";
		cin >> num;
		cout << endl;
	}
	JosephList.create(num);

	cout << "请输入报数的起始位置:";
	cin >> start;

	cout << "请输入出列所需报的数字:";
	cin >> rank;

	cout << "原序列为：" << endl;
	JosephList.print();

	cout << "新序列为: " << endl;
	JosephList.Joseph(start, rank);

	return 0;
}
