//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mystudentsys.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MYSTUDENTSYS_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BKBUTTON                    131
#define IDB_BITMAP2                     132
#define IDI_ICON1                       134
#define IDR_MENU1                       135
#define IDD_DIg_subjectinfo             136
#define IDR_TOOLBAR_subjectinfo         137
#define IDD_DIginfostudent              139
#define IDD_DIgexaminfo_submark         140
#define IDD_DIggrade_leveldlg           141
#define IDD_Dlgregbreak_find            144
#define IDD_LOGIN                       145
#define IDC_subjectname                 1000
#define IDC_subjectid                   1001
#define IDC_studentname                 1001
#define IDC_studentage                  1002
#define IDC_sutentid                    1002
#define IDC_studentphone                1003
#define IDC_examsubject                 1003
#define IDC_findstudent_id              1004
#define IDC_submarks                    1004
#define IDC_studentsex                  1005
#define IDC_examkind                    1005
#define IDC_studentclass                1006
#define IDC_studentaddr                 1007
#define IDC_inputsave_marks             1010
#define IDC_examdate_picker             1017
#define IDC_COMBO1                      1018
#define IDC_EDIT_upgrade                1019
#define IDC_Btn_setgradelevel           1020
#define IDC_EDIT_lowgrade               1021
#define IDC_Btn_findbest                1022
#define IDC_Btnfindbetter               1023
#define IDC_Btnfindnormal               1024
#define IDC_Btnfindworse                1025
#define IDC_LIST3                       1027
#define IDC_EDIT_studentid              1028
#define IDC_Btnfind_regbreakinfo        1029
#define IDC_EDIT_regcontent             1030
#define IDC_EDIT_reghandleresult        1031
#define IDC_EDIT_regmemo                1032
#define IDC_regfind_date                1033
#define IDC_LIST2                       1034
#define IDC_EDIT1                       1035
#define IDC_EDIT2                       1036
#define ID_MENU_officeinfo              32771
#define ID_MENU_subjectinfo             32772
#define ID_MENU_teacherinfo             32773
#define ID_MENU_classinfo               32774
#define ID_MENU_classsubject            32775
#define ID_MENU_examkind                32776
#define ID_MENU_infostudent             32777
#define ID_MENU_inputmarks              32778
#define ID_MENU_gradeleveldlg           32779
#define ID_MENU_regbreakinfo            32780
#define ID_MENU_studentinfo             32781
#define ID_MENU_markreport              32782
#define ID_MENU_findbreakinfo           32783
#define ID_MENU_user                    32784
#define ID_MENU_exit                    32785
#define ID_MENU_help                    32786
#define ID_ABOUT                        32787
#define ID_subjectinfo_toolbar_add      32788
#define ID_subjectinfo_toolbar_save     32789
#define ID_subjectinfo_toolbar_del      32790
#define ID_subjectinfo_toolbar_first    32792
#define ID_subjectinfo_toolbar_pre      32793
#define ID_subjectinfo_toolbar_next     32794
#define ID_subjectinfo_toolbar_last     32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
